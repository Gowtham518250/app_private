import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api_client.dart';
import 'sync_queue_manager.dart';

/// Durable local-first attendance operations.
/// The user action is committed to local storage + outbox before any network call.
class OfflineAttendanceService {
  static const String _prefix = 'attendance_local_v2_';

  static Future<int?> _userId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('user_id') ?? prefs.getInt('userId');
  }

  static Future<String> _key(int userId) async => '$_prefix$userId';

  static Future<List<Map<String, dynamic>>> loadLocalRecords() async {
    final uid = await _userId();
    if (uid == null || uid <= 0) return <Map<String, dynamic>>[];
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(await _key(uid));
    if (raw == null || raw.isEmpty) return <Map<String, dynamic>>[];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return <Map<String, dynamic>>[];
      return decoded
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  static Future<void> _saveRecords(List<Map<String, dynamic>> records) async {
    final uid = await _userId();
    if (uid == null || uid <= 0) return;
    final prefs = await SharedPreferences.getInstance();
    final dedup = <String, Map<String, dynamic>>{};
    for (final record in records) {
      final key = '${record['worker_id'] ?? record['employee_id'] ?? uid}:${record['attendance_date'] ?? ''}';
      dedup[key] = record;
    }
    await prefs.setString(await _key(uid), jsonEncode(dedup.values.toList()));
  }

  static Future<void> _upsertLocal({
    required int employeeId,
    int? workerId,
    required String date,
    DateTime? checkIn,
    DateTime? checkOut,
    String? status,
    double? workingHours,
  }) async {
    final records = await loadLocalRecords();
    final index = records.indexWhere((r) =>
        (r['worker_id']?.toString() ?? '') == (workerId?.toString() ?? '') &&
        (r['employee_id']?.toString() ?? '') == employeeId.toString() &&
        (r['attendance_date']?.toString().split('T').first ?? '') == date);

    final existing = index >= 0 ? Map<String, dynamic>.from(records[index]) : <String, dynamic>{};
    final merged = <String, dynamic>{
      ...existing,
      'employee_id': employeeId,
      if (workerId != null) 'worker_id': workerId,
      'attendance_date': date,
      if (checkIn != null) 'check_in_time': checkIn.toUtc().toIso8601String(),
      if (checkOut != null) 'check_out_time': checkOut.toUtc().toIso8601String(),
      if (status != null) 'status': status.toUpperCase(),
      if (workingHours != null) 'working_hours': workingHours,
      'local_pending': true,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };

    if (index >= 0) {
      records[index] = merged;
    } else {
      records.add(merged);
    }
    await _saveRecords(records);
  }

  static Future<bool> checkIn({required int employeeId, int? workerId}) async {
    final now = DateTime.now();
    final date = '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    final operationId = 'ATT_IN_${workerId ?? employeeId}_$date';

    await _upsertLocal(
      employeeId: employeeId,
      workerId: workerId,
      date: date,
      checkIn: now,
      status: 'PRESENT',
    );

    final queued = await SyncQueueManager.enqueue('attendance_check_in', {
      'operation_id': operationId,
      'idempotency_key': operationId,
      'employee_id': employeeId,
      'worker_id': workerId,
      'attendance_date': date,
    });

    if (!queued) {
      throw StateError('Unable to persist attendance check-in to durable outbox');
    }
    return true;
  }

  static Future<bool> checkOut({required int employeeId, int? workerId}) async {
    final now = DateTime.now();
    final date = '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    final records = await loadLocalRecords();
    Map<String, dynamic>? existing;
    for (final r in records) {
      if ((r['worker_id']?.toString() ?? '') == (workerId?.toString() ?? '') &&
          (r['employee_id']?.toString() ?? '') == employeeId.toString() &&
          (r['attendance_date']?.toString().split('T').first ?? '') == date) {
        existing = r;
        break;
      }
    }

    DateTime? checkIn;
    final rawCheckIn = existing?['check_in_time'];
    if (rawCheckIn != null) checkIn = DateTime.tryParse(rawCheckIn.toString());
    final workingHours = checkIn == null ? null : now.difference(checkIn.toLocal()).inSeconds / 3600.0;
    final operationId = 'ATT_OUT_${workerId ?? employeeId}_$date';

    await _upsertLocal(
      employeeId: employeeId,
      workerId: workerId,
      date: date,
      checkOut: now,
      workingHours: workingHours,
      status: 'PRESENT',
    );

    final queued = await SyncQueueManager.enqueue('attendance_check_out', {
      'operation_id': operationId,
      'idempotency_key': operationId,
      'employee_id': employeeId,
      'worker_id': workerId,
      'attendance_date': date,
    });

    if (!queued) {
      throw StateError('Unable to persist attendance check-out to durable outbox');
    }
    return true;
  }

  static Future<void> reconcileFromBackend() async {
    final uid = await _userId();
    if (uid == null || uid <= 0) return;
    try {
      final today = DateTime.now();
      final date = '${today.year.toString().padLeft(4, '0')}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
      final response = await ApiClient.getJson('${ApiClient.attendancePrefix}/date/$date');
      if (response.statusCode != 200) return;
      final decoded = jsonDecode(response.body);
      if (decoded is! Map || decoded['records'] is! List) return;

      final remote = (decoded['records'] as List)
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
      final local = await loadLocalRecords();
      final merged = <String, Map<String, dynamic>>{};
      for (final r in [...local, ...remote]) {
        final key = '${r['worker_id'] ?? r['employee_id'] ?? uid}:${r['attendance_date'] ?? ''}';
        final previous = merged[key];
        if (previous == null) {
          merged[key] = r;
        } else if (r['local_pending'] == true && previous['local_pending'] != true) {
          merged[key] = r;
        } else {
          merged[key] = {...previous, ...r, 'local_pending': previous['local_pending'] == true};
        }
      }
      await _saveRecords(merged.values.toList());
    } catch (e) {
      if (kDebugMode) debugPrint('OfflineAttendance reconcile skipped: $e');
    }
  }
  static Future<void> markSynced({required int employeeId, int? workerId, required String date}) async {
    final records = await loadLocalRecords();
    for (int i = 0; i < records.length; i++) {
      final r = records[i];
      if ((r['employee_id']?.toString() ?? '') == employeeId.toString() &&
          (r['worker_id']?.toString() ?? '') == (workerId?.toString() ?? '') &&
          (r['attendance_date']?.toString().split('T').first ?? '') == date) {
        records[i] = {
          ...r,
          'local_pending': false,
          'synced_at': DateTime.now().toUtc().toIso8601String(),
        };
        await _saveRecords(records);
        return;
      }
    }
  }

}
